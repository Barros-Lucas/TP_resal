Ce dossier contient un client Udp et un serveur Udp en python conformément à l'exercice "TP Réseau n°1".
cf. sujet pdf "tp_réseau_1.pdf", 
proposé par Mr Jacoboni L3 Miashs, Université Jean Jaurès Toulouse.


note: Le client et le serveur devrons être lancés avec python3.7 pour être sûr de leur bon fonctionnement
Le fichier serveurDate_Linux est un programme d'exemple proposé par Mr Jacoboni
