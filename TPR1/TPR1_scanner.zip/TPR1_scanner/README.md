Ce dossier contient un serveur tcp et un scanner de port en python conformément à l'exercice "TP Réseau n°1".
cf. sujet pdf "tp_réseau_1.pdf", 
proposé par Mr Jacoboni L3 Miashs, Université Jean Jaurès Toulouse.


note: Ce scanner ne test que les ports tcp ouvert sur un hôte. Des problèmes étant survenu lors du test de scan des ports udp. Il existe des solutions mais elles partent du principes que les serveurs Udp soient bien configuré et répondent à une requête non comprise.
Le serveurTCP d'exemple sert de vérification en lançant un serveur sur l'hôte local
